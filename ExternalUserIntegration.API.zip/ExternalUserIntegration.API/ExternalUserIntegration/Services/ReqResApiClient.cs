﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using ExternalUserIntegration.Exceptions;
using ExternalUserIntegration.Model;

namespace ExternalUserIntegration.Services
{


    //public class ReqResApiClient
    //{
    //    private readonly HttpClient _httpClient;
    //    public ReqResApiClient(HttpClient httpClient)
    //    {
    //        _httpClient = httpClient;
    //    }
    //}

    public class ReqResApiClient
    {
        private readonly HttpClient _httpClient;
        private readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        public ReqResApiClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri("https://reqres.in/");     
        }

        public async Task<User?> GetUserByIdAsync(int userId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"https://reqres.in/api/users/{userId}");

                if (response.StatusCode == HttpStatusCode.NotFound)
                    return null; // Or throw new NotFoundException(userId);

                response.EnsureSuccessStatusCode();

                var content = await response.Content.ReadAsStringAsync();

                var result = JsonSerializer.Deserialize<UserResponse>(content, _jsonOptions);

                return result?.Data;
            }
            catch (HttpRequestException ex)
            {
                throw new ExternalApiException("Error while calling ReqRes API", ex);
            }
            catch (TaskCanceledException ex)
            {
                throw new ExternalApiException("Timeout while calling ReqRes API", ex);
            }
            catch (JsonException ex)
            {
                throw new ExternalApiException("Error deserializing ReqRes API response", ex);
            }
        }

        public async Task<IEnumerable<User>> GetAllUsersAsync()
        {
            var users = new List<User>();
            int page = 1;
            bool hasMore;

            do
            {
                try
                {
                    var response = await _httpClient.GetAsync($"https://reqres.in/api/users?page={page}");
                   // var response = await _httpClient.GetAsync($"httpapi/users?page={page}");

                    response.EnsureSuccessStatusCode();

                    var content = await response.Content.ReadAsStringAsync();

                    var result = JsonSerializer.Deserialize<UserListResponse>(content, _jsonOptions);

                    if (result?.Data != null)
                    {
                        users.AddRange(result.Data);
                        hasMore = page < result.Total_Pages;
                        page++;
                    }
                    else
                    {
                        hasMore = false;
                    }
                }
                catch (Exception ex)
                {
                    throw new ExternalApiException($"Failed to get users on page {page}", ex);
                }
            } while (hasMore);

            return users;
        }

    }

    //public class ReqResApiClient
    //{
    //    private readonly HttpClient _httpClient;
    //    private readonly JsonSerializerOptions _jsonOptions = new(JsonSerializerDefaults.Web);

    //    public ReqResApiClient(HttpClient httpClient)
    //    {
    //        _httpClient = httpClient;
    //        _httpClient.BaseAddress = new Uri("https://reqres.in/api/");
    //    }

    //    public async Task<User?> GetUserByIdAsync(int userId)
    //    {
    //        var response = await _httpClient.GetAsync($"users/{userId}");
    //        response.EnsureSuccessStatusCode();

    //        var content = await response.Content.ReadAsStringAsync();
    //        var result = JsonSerializer.Deserialize<UserResponse>(content, _jsonOptions);
    //        return result?.Data;
    //    }

    //    public async Task<List<User>> GetAllUsersAsync()
    //    {
    //        int page = 1;
    //        var users = new List<User>();

    //        while (true)
    //        {
    //            var response = await _httpClient.GetAsync($"users?page={page}");
    //            response.EnsureSuccessStatusCode();

    //            var content = await response.Content.ReadAsStringAsync();
    //            var result = JsonSerializer.Deserialize<UserListResponse>(content, _jsonOptions);

    //            if (result?.Data == null || result.Data.Count == 0)
    //                break;

    //            users.AddRange(result.Data);

    //            if (page >= result.TotalPages)
    //                break;

    //            page++;
    //        }

    //        return users;
    //    }
    //}

}
