﻿namespace ExternalUserIntegration
{
    public class Class1
    {

    }
}
