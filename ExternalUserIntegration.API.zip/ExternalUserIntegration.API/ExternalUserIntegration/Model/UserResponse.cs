﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalUserIntegration.Model
{
    public class UserResponse
    {
        public  User? Data { get; set; }
    }
}
