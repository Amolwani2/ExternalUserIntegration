﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExternalUserIntegration.Model;

namespace ExternalUserIntegration.Services
{
    public class ExternalUserService
    {
        private readonly ReqResApiClient _apiClient;

        public ExternalUserService(ReqResApiClient apiClient)
        {
            _apiClient = apiClient;
        }

        public async Task<User> GetUserByIdAsync(int userId)
        {
            return await _apiClient.GetUserByIdAsync(userId);
        }

        public async Task<IEnumerable<User>> GetAllUsersAsync()
        {
            return await _apiClient.GetAllUsersAsync();
        }
    }
}
